﻿
using var game = new Sprint_0.Game1();
game.Run();
